<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>404 - Page Not Found mark</title>
        <link href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css" rel="stylesheet">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <style>
            body {
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                margin: 0;
                background-color: #f5f5f5
            }

            .centered-content {
                text-align: center
            }

            .centered-content h1 {
                font-size: 6rem
            }

            .centered-content p {
                font-size: 1.5rem
            }

            .telegram-link {
                margin-top: 20px
            }
        </style>
    </head>
    <body>
        <div class="centered-content">
            <h1>
                <i class="material-icons medium">error_outline</i>
                404
            </h1>
            <p>Oops! The page you're looking for cannot be found.</p>
            <a href="https://telegram.me/xxx" class="btn waves-effect waves-light telegram-link">
                <i class="material-icons left">send</i>
                Visit our Telegram Channel

            </a>
        </div>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
        <script>
            (function() {
                function c() {
                    var b = a.contentDocument || a.contentWindow.document;
                    if (b) {
                        var d = b.createElement('script');
                        d.innerHTML = "window.__CF$cv$params={r:'8bdfb350ccf95fbd',t:'MTcyNTQ3MDk1My4wMDAwMDA='};var a=document.createElement('script');a.nonce='';a.src='/cdn-cgi/challenge-platform/scripts/jsd/main.js';document.getElementsByTagName('head')[0].appendChild(a);";
                        b.getElementsByTagName('head')[0].appendChild(d)
                    }
                }
                if (document.body) {
                    var a = document.createElement('iframe');
                    a.height = 1;
                    a.width = 1;
                    a.style.position = 'absolute';
                    a.style.top = 0;
                    a.style.left = 0;
                    a.style.border = 'none';
                    a.style.visibility = 'hidden';
                    document.body.appendChild(a);
                    if ('loading' !== document.readyState)
                        c();
                    else if (window.addEventListener)
                        document.addEventListener('DOMContentLoaded', c);
                    else {
                        var e = document.onreadystatechange || function() {}
                        ;
                        document.onreadystatechange = function(b) {
                            e(b);
                            'loading' !== document.readyState && (document.onreadystatechange = e,
                            c())
                        }
                    }
                }
            }
            )();
        </script>
    </body>
</html>
