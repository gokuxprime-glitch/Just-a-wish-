<?php
$name = ' ♥️💫 𝐅𝐋𝐀𝐒𝐇๛𝐎𝐏๛♥️💫';

$emailku = 'alfajk180@gmail.com';
?>