<?php
header("Location: ./FAS125/");
exit();
?>